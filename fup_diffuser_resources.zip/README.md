# FUP DIFFUSER — 제작 리소스 팩

**THE GOLDEN RETRIEVER** 디퓨저 TVC(2026)를 만들며 직접 제작한 Blender 리소스입니다.
자유롭게 가져다 쓰세요. — FUP (from us project)

## 담긴 파일

### 1. `fup_scrim_light.py` — 스크림 라이트 애드온
상용 애드온 Light Wrangler의 Scrim 모드를 numpy로 재현한 자체 Blender 애드온.
**Feathering 값 하나로 사각(소프트박스) ↔ 원형(원반) 조명이 연속으로 바뀝니다.**
- 설치: Blender > Edit > Preferences > Add-ons > Install > 이 파일 선택
- 사용: 라이트 속성 탭 / 3D 뷰포트 N패널 > Scrim
- 원리: 사각 거리(체비쇼프)와 원형 거리(유클리드)를 섞어 패턴 이미지를 굽고, 더블 버퍼로 Cycles 뷰포트를 실시간 갱신

### 2. `scotland_nodes.py` — 스코틀랜드 석양 씬 노드 레시피
자연 배경의 핵심 노드 셋업 3종을 재사용 가능한 함수로 정리:
- `build_deep_orange_sky()` — HDRI를 딥오렌지로 그레이딩하는 World (Hue/Saturation 삽입)
- `build_fog_stack()` — 거리별 4겹 안개 (근경→중경 발광벽→원경→전역 헤이즈)
- `build_film_grain()` — AgX에 안 눌리는 곱셈식 필름 그레인 컴포지터

### 3. `download_assets.sh` — 무료 에셋 다운로드
Poly Haven(CC0)·BlendKit에서 HDRI·바위·풀을 API로 직접 받는 스크립트.
격자 배열·include 파일 등 실전 주의점을 주석에 담았습니다.

## 라이선스
자체 제작물은 자유 사용. 외부 에셋(Poly Haven=CC0, BlendKit)은 각 사이트 라이선스를 따르세요.

Made with Claude Code + Blender 5.1 · 2026
