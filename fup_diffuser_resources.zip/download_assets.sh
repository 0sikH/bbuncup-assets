#!/usr/bin/env bash
# FUP DIFFUSER — 무료 3D 에셋 다운로드 스크립트
# THE GOLDEN RETRIEVER TVC의 스코틀랜드 배경에 쓴 HDRI·바위·풀을 받는 방법.
# Blender 애드온 없이 각 사이트 공개 REST API를 curl로 직접 호출합니다.
# (Poly Haven = CC0 완전자유 / BlendKit = 로열티프리, 상업 사용 전 개별 라이선스 확인 권장)

set -e

# ── Poly Haven (https://api.polyhaven.com) — HDRI · 바위 · 풀, 전부 CC0 ──
# HDRI 4K EXR 받기 (최종에 쓴 하늘)
HDRI="kiara_8_sunset"
URL=$(curl -sL "https://api.polyhaven.com/files/${HDRI}" \
      | python3 -c "import json,sys; print(json.load(sys.stdin)['hdri']['4k']['exr']['url'])")
curl -sL "$URL" -o "${HDRI}_4k.exr"
echo "받음: ${HDRI}_4k.exr"

# 자연 모델 목록 (잔디 클럼프 grass_medium_01/02, 이끼 바위 rock_moss_set_02 등)
curl -sL "https://api.polyhaven.com/assets?type=models&categories=nature" | python3 -m json.tool | head -40

# ⚠️ Poly Haven 모델 blend는 텍스처가 include로 분리돼 있어
#    blend + include 파일을 함께 받아 상대경로를 유지해야 한다.
#    어펜드 후 배치 계산 전후로 bpy.context.view_layer.update() 필수.
#    잔디 클럼프는 blend 안에서 격자 배열이라 그룹째 배치 금지 → 개별 오브젝트로 산개.

# ── BlendKit (https://www.blendkit.com/api/v1) — 이끼 지형 · 소품 ──
# 검색 (availability:free, asset_type:model 쿼리 문법)
curl -sL "https://www.blendkit.com/api/v1/search/?query=rock+moss+availability:free+asset_type:model" \
     | python3 -m json.tool | head -30

# 다운로드 — scene_uuid에 제로 UUID를 넘기면 무료 다운로드 URL을 준다
# id=$(위 검색 결과의 assetBaseId)
# curl -sL "https://www.blendkit.com/api/v1/downloads/${id}/?scene_uuid=00000000-0000-0000-0000-000000000000"

echo "완료. Poly Haven=CC0, BlendKit=상업 사용 전 라이선스 확인."
