# FUP Scrim Light — Light Wrangler Scrim 모드 재현
# 패턴을 이미지로 계산해 라이트 텍스처 + 프리뷰에 동일하게 사용
bl_info = {
    "name": "FUP Scrim Light",
    "author": "FUP / Claude",
    "version": (2, 0, 0),
    "blender": (4, 0, 0),
    "location": "라이트 속성 탭 · 3D 뷰포트 N패널 > Scrim",
    "description": "고정 사각 프레임 + 원형 그라데이션 스크림 (실시간 프리뷰)",
    "category": "Lighting",
}

import bpy
import math
import numpy as np
import bpy.utils.previews

RES = 256
# 더블 버퍼: 픽셀만 바꾸면 Cycles 뷰포트가 갱신을 놓치므로
# 반대쪽 버퍼에 쓰고 텍스처 노드에 교체 장착한다
IMG_NAMES = ("FUP_ScrimPattern_A", "FUP_ScrimPattern_B")

_pcoll = None
_prev_key = None
_noise_cache = None

# LW Scrim 파라미터 (Radius 없음 — Feathering이 사각↔원을 오감)
SCRIM_DEFAULTS = {
    "Feathering": 1.0,
    "Tilt H": 0.0,
    "Tilt V": 0.0,
    "Imperfection": 0.15,
}
SCRIM_RANGES = {
    "Feathering": (0.0, 1.0),
    "Tilt H": (-89.0, 89.0),
    "Tilt V": (-89.0, 89.0),
    "Imperfection": (0.0, 1.0),
}
DEFAULT_ENERGY = 28.0


# ---------- 헬퍼 ----------

def get_scrim_node(light):
    if light and light.use_nodes and light.node_tree:
        n = light.node_tree.nodes.get("Scrim")
        if n and n.bl_idname == 'ShaderNodeGroup' and n.node_tree:
            return n
        for n in light.node_tree.nodes:
            if n.bl_idname == 'ShaderNodeGroup' and n.node_tree \
                    and n.node_tree.name.startswith("ScrimLight"):
                return n
    return None


def find_scrim_light_object(context=None):
    scene_objs = (context.scene.objects if context else bpy.data.objects)
    ob = context.object if context else None
    if ob and ob.type == 'LIGHT' and get_scrim_node(ob.data):
        return ob
    for o in scene_objs:
        if o.type == 'LIGHT' and get_scrim_node(o.data):
            return o
    return None


def get_track_target(light_obj):
    for c in light_obj.constraints:
        if c.type in {'DAMPED_TRACK', 'TRACK_TO'} and c.target:
            return c.target
    return None


def is_lw_mode(node):
    """이미지 기반 LW 스크림으로 재구성됐는지"""
    return node and node.node_tree.nodes.get("ScrimImage") is not None


def apply_socket_ranges(group_tree):
    for name, (lo, hi) in SCRIM_RANGES.items():
        for item in group_tree.interface.items_tree:
            if getattr(item, "item_type", None) == 'SOCKET' \
                    and item.in_out == 'INPUT' and item.name == name:
                item.min_value = lo
                item.max_value = hi
                break


# ---------- 패턴 계산 (LW Scrim 수식) ----------

def _bilinear_upsample(g, res):
    c = g.shape[0] - 1
    xs = np.linspace(0, c, res)
    x0 = np.clip(np.floor(xs).astype(int), 0, c - 1)
    fx = xs - x0
    g1 = g[x0, :] * (1 - fx)[:, None] + g[x0 + 1, :] * fx[:, None]
    g2 = g1[:, x0] * (1 - fx)[None, :] + g1[:, x0 + 1] * fx[None, :]
    return g2


def _get_noise():
    global _noise_cache
    if _noise_cache is None:
        rng = np.random.default_rng(7)
        n = _bilinear_upsample(rng.random((7, 7)), RES)
        n += 0.5 * _bilinear_upsample(rng.random((15, 15)), RES)
        n -= n.min()
        n /= n.max()
        _noise_cache = n
    return _noise_cache


def _render_pattern(feather, th, tv, imp):
    """Feathering: 0=꽉 찬 사각 → 1=원형 그라데이션
    Tilt: 스크림 판 기울임 — 한쪽 가장자리로 압축 + 밝아짐"""
    ax = np.linspace(-1.0, 1.0, RES)
    U, V = np.meshgrid(ax, ax)

    def tilt_inverse(u, deg):
        t = math.sin(math.radians(max(min(deg, 89.0), -89.0)))
        den = np.maximum(1.0 - t * u, 1e-4)
        x = (u - t) / den                      # 화면좌표 → 스크림 원좌표
        gain = (1.0 - t * t) / (den * den)     # 압축된 쪽 밝기 증가
        return x, gain

    X, gx = tilt_inverse(U, th)
    Y, gy = tilt_inverse(V, tv)

    f = max(min(feather, 1.0), 0.0)
    d_sq = np.maximum(np.abs(X), np.abs(Y))    # 사각 거리
    d_rd = np.sqrt(X * X + Y * Y)              # 원형 거리
    d = (1.0 - f) * d_sq + f * d_rd
    start = (1.0 - f) * 0.86                   # f=0: 가장자리만 페이드
    tt = np.clip((d - start) / max(1.0 - start, 1e-4), 0.0, 1.0)
    tt = tt * tt * (3.0 - 2.0 * tt)            # smoothstep
    inten = (1.0 - tt) * np.clip(gx * gy, 0.0, 4.0)
    imp = max(min(imp, 1.0), 0.0)
    inten *= (1.0 - imp) + imp * _get_noise()
    return np.clip(inten, 0.0, 1.0).astype(np.float32)


# ---------- 이미지/프리뷰 갱신 ----------

def _scrim_image(name=None):
    name = name or IMG_NAMES[0]
    img = bpy.data.images.get(name)
    if img is None or tuple(img.size) != (RES, RES):
        if img:
            bpy.data.images.remove(img)
        img = bpy.data.images.new(name, RES, RES)
        img.colorspace_settings.name = 'Non-Color'
        img.use_fake_user = True
    return img


def _write_pattern_to_light(node, pattern):
    """반대쪽 버퍼에 쓰고 텍스처 노드에 교체 → Cycles 뷰포트 강제 갱신"""
    tex = node.node_tree.nodes.get("ScrimImage")
    if tex is None:
        return
    cur = tex.image.name if tex.image else ""
    nxt = IMG_NAMES[1] if cur == IMG_NAMES[0] else IMG_NAMES[0]
    img = _scrim_image(nxt)
    rgba = np.empty((RES, RES, 4), dtype=np.float32)
    rgba[..., 0] = pattern
    rgba[..., 1] = pattern
    rgba[..., 2] = pattern
    rgba[..., 3] = 1.0
    try:
        img.pixels.foreach_set(rgba.ravel())
    except (AttributeError, TypeError):
        img.pixels[:] = rgba.ravel().tolist()
    img.update_tag()
    try:
        img.pack()
    except Exception:
        pass
    tex.image = img                     # 노드 변경 → 셰이더 리빌드 + 텍스처 재업로드
    node.node_tree.update_tag()


def _scrim_values(light_obj):
    node = get_scrim_node(light_obj.data)
    if node is None:
        return None
    def v(name, d=0.0):
        return float(node.inputs[name].default_value) if name in node.inputs else d
    col = node.inputs["Color"].default_value if "Color" in node.inputs else (1, 1, 1, 1)
    ld = light_obj.data
    sx = ld.size
    sy = ld.size_y if ld.shape in {'RECTANGLE', 'ELLIPSE'} else ld.size
    return (v("Feathering", 1.0), v("Tilt H"), v("Tilt V"), v("Imperfection"),
            col[0], col[1], col[2], sx, sy)


def _update_all():
    """값이 바뀌었으면 라이트 이미지 + 프리뷰 아이콘 재생성"""
    global _prev_key
    if _pcoll is None:
        return False
    light_obj = find_scrim_light_object()
    if light_obj is None:
        return False
    node = get_scrim_node(light_obj.data)
    if not is_lw_mode(node):
        return False
    vals = _scrim_values(light_obj)
    if vals is None or vals == _prev_key:
        return False
    _prev_key = vals
    fe, th, tv, imp, r, g, b, sx, sy = vals

    pattern = _render_pattern(fe, th, tv, imp)

    # 1) 라이트 텍스처 (더블 버퍼 교체 — 뷰포트 강제 갱신)
    _write_pattern_to_light(node, pattern)

    # 2) 프레임 가로/세로 반영 (좌표 매핑 — 패턴이 프레임에 꽉 차게)
    mp = node.node_tree.nodes.get("ScrimMapping")
    if mp:
        mp.inputs["Scale"].default_value = (1.0 / max(sx, 1e-3),
                                            1.0 / max(sy, 1e-3), 1.0)

    # 3) 프리뷰 아이콘 (컬러 + 프레임 비율 레터박스)
    colored = np.empty((RES, RES, 4), dtype=np.float32)
    colored[..., 0] = pattern * r
    colored[..., 1] = pattern * g
    colored[..., 2] = pattern * b
    colored[..., 3] = 1.0
    aspect = max(sx, 1e-6) / max(sy, 1e-6)
    if abs(aspect - 1.0) < 1e-3:
        prgba = colored
    else:
        prgba = np.zeros((RES, RES, 4), dtype=np.float32)
        prgba[..., 3] = 1.0
        if aspect > 1.0:   # 가로로 김 → 위아래 검정 띠
            h = max(int(round(RES / aspect)), 2)
            yi = np.clip(np.round(np.linspace(0, RES - 1, h)).astype(int), 0, RES - 1)
            y0 = (RES - h) // 2
            prgba[y0:y0 + h, :, :] = colored[yi, :, :]
        else:              # 세로로 김 → 좌우 검정 띠
            w = max(int(round(RES * aspect)), 2)
            xi = np.clip(np.round(np.linspace(0, RES - 1, w)).astype(int), 0, RES - 1)
            x0 = (RES - w) // 2
            prgba[:, x0:x0 + w, :] = colored[:, xi, :]
    p = _pcoll.get("scrim") or _pcoll.new("scrim")
    p.image_size = (RES, RES)
    try:
        p.image_pixels_float.foreach_set(prgba.ravel())
    except (AttributeError, TypeError):
        p.image_pixels_float[:] = prgba.ravel().tolist()
    icon = prgba[::8, ::8, :]
    p.icon_size = (32, 32)
    try:
        p.icon_pixels_float.foreach_set(icon.ravel())
    except (AttributeError, TypeError):
        p.icon_pixels_float[:] = icon.ravel().tolist()
    return True


def _preview_timer():
    try:
        if _update_all():
            wm = bpy.context.window_manager
            if wm:
                for w in wm.windows:
                    for a in w.screen.areas:
                        if a.type in {'PROPERTIES', 'VIEW_3D'}:
                            a.tag_redraw()
    except Exception:
        pass
    return 0.2


def get_preview_icon():
    if _pcoll is None:
        return 0
    p = _pcoll.get("scrim")
    return p.icon_id if p else 0


# ---------- 노드 그룹 재구성 (이미지 기반) ----------

def rebuild_group_lw(node):
    """ScrimLight 그룹 내부를 이미지 텍스처 기반으로 재구성"""
    ng = node.node_tree
    ng.nodes.clear()
    gi = ng.nodes.new('NodeGroupInput'); gi.location = (-200, -250)
    go = ng.nodes.new('NodeGroupOutput'); go.location = (700, 0)

    tc = ng.nodes.new('ShaderNodeTexCoord'); tc.location = (-750, 0)
    mp = ng.nodes.new('ShaderNodeMapping'); mp.location = (-550, 0)
    mp.name = "ScrimMapping"
    mp.label = "프레임 좌표 (자동)"
    mp.inputs["Location"].default_value = (0.5, 0.5, 0.0)
    tex = ng.nodes.new('ShaderNodeTexImage'); tex.location = (-300, 0)
    tex.name = "ScrimImage"
    tex.label = "스크림 패턴 (자동 생성)"
    tex.image = _scrim_image()
    tex.extension = 'CLIP'
    tex.interpolation = 'Linear'

    mul = ng.nodes.new('ShaderNodeVectorMath'); mul.operation = 'MULTIPLY'
    mul.location = (100, 0)
    emi = ng.nodes.new('ShaderNodeEmission'); emi.location = (400, 0)

    ng.links.new(tc.outputs['Object'], mp.inputs['Vector'])
    ng.links.new(mp.outputs['Vector'], tex.inputs['Vector'])
    ng.links.new(tex.outputs['Color'], mul.inputs[0])
    ng.links.new(gi.outputs['Color'], mul.inputs[1])
    ng.links.new(mul.outputs['Vector'], emi.inputs['Color'])
    ng.links.new(emi.outputs['Emission'], go.inputs['Shader'])


# ---------- 오퍼레이터 ----------

class FUP_OT_scrim_convert(bpy.types.Operator):
    """LW 스크림 모드로 변환: 고정 사각 프레임 + 이미지 패턴 (조준 리그 제거)"""
    bl_idname = "fup.scrim_convert"
    bl_label = "LW 스크림 모드로 변환"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global _prev_key
        ob = find_scrim_light_object(context)
        if ob is None:
            self.report({'WARNING'}, "씬에 Scrim 라이트가 없습니다")
            return {'CANCELLED'}
        # 조준 방향 유지한 채 트래킹 제거
        mw = ob.matrix_world.copy()
        for c in list(ob.constraints):
            if c.type in {'DAMPED_TRACK', 'TRACK_TO'}:
                ob.constraints.remove(c)
        ob.matrix_world = mw
        ob.data.shape = 'SQUARE'
        # 옛 리그 정리
        for name in ("BacklightTarget", "ScrimPreview"):
            o = bpy.data.objects.get(name)
            if o:
                bpy.data.objects.remove(o, do_unlink=True)
        pm = bpy.data.materials.get("ScrimPreview")
        if pm:
            bpy.data.materials.remove(pm)
        # 노드 그룹 재구성 + 값 리셋
        node = get_scrim_node(ob.data)
        rebuild_group_lw(node)
        apply_socket_ranges(node.node_tree)
        for name, val in SCRIM_DEFAULTS.items():
            if name in node.inputs:
                node.inputs[name].default_value = val
        _prev_key = None
        _update_all()
        self.report({'INFO'}, "LW 스크림 모드로 변환 완료")
        return {'FINISHED'}


class FUP_OT_scrim_fix_scale(bpy.types.Operator):
    """오브젝트 스케일을 프레임 크기로 흡수하고 (1,1,1)로 정규화"""
    bl_idname = "fup.scrim_fix_scale"
    bl_label = "스케일 정규화"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global _prev_key
        ob = find_scrim_light_object(context)
        if ob is None:
            self.report({'WARNING'}, "씬에 Scrim 라이트가 없습니다")
            return {'CANCELLED'}
        sx, sy, _ = ob.scale
        ax, ay = abs(sx), abs(sy)
        ld = ob.data
        if max(ax, ay) > 1e-6:
            if ld.shape in {'RECTANGLE', 'ELLIPSE'}:
                ld.size *= ax
                ld.size_y *= ay
            elif abs(ax - ay) > 1e-3:
                # 비율이 다르면 늘린 모양 그대로 직사각으로 전환
                ld.shape = 'RECTANGLE'
                ld.size_y = ld.size * ay
                ld.size = ld.size * ax
            else:
                ld.size *= (ax + ay) / 2.0
        ob.scale = (1.0, 1.0, 1.0)
        _prev_key = None
        _update_all()
        self.report({'INFO'}, "정규화 완료 — 늘린 비율은 프레임 크기로 흡수됨")
        return {'FINISHED'}


class FUP_OT_scrim_reset(bpy.types.Operator):
    """Scrim 값을 권장 기본값으로 리셋"""
    bl_idname = "fup.scrim_reset"
    bl_label = "권장값으로 리셋"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global _prev_key
        ob = find_scrim_light_object(context)
        if ob is None:
            self.report({'WARNING'}, "씬에 Scrim 라이트가 없습니다")
            return {'CANCELLED'}
        node = get_scrim_node(ob.data)
        apply_socket_ranges(node.node_tree)
        for name, val in SCRIM_DEFAULTS.items():
            if name in node.inputs:
                node.inputs[name].default_value = val
        ob.data.energy = DEFAULT_ENERGY
        _prev_key = None
        _update_all()
        self.report({'INFO'}, "Scrim 권장값으로 리셋 완료")
        return {'FINISHED'}


class FUP_OT_select_scrim_light(bpy.types.Operator):
    """씬의 Scrim 라이트(BottleBacklight)를 선택"""
    bl_idname = "fup.select_scrim_light"
    bl_label = "Scrim 라이트로 이동"

    def execute(self, context):
        ob = find_scrim_light_object(context)
        if ob is None:
            self.report({'WARNING'}, "씬에 Scrim 라이트가 없습니다")
            return {'CANCELLED'}
        for o in context.selected_objects:
            o.select_set(False)
        ob.select_set(True)
        context.view_layer.objects.active = ob
        return {'FINISHED'}


# ---------- 공용 UI ----------

def draw_scrim_ui(layout, context, light_obj):
    light = light_obj.data
    node = get_scrim_node(light)
    if node is None:
        layout.label(text="Scrim 노드 그룹이 없습니다", icon='ERROR')
        return

    # 변환 안내 (구형 리그이거나 사각이 아닐 때)
    if not is_lw_mode(node) or get_track_target(light_obj) \
            or light.shape != 'SQUARE':
        box = layout.box()
        box.label(text="LW 방식으로 전환이 필요합니다", icon='INFO')
        box.operator("fup.scrim_convert", icon='MOD_LATTICE')
        if not is_lw_mode(node):
            return

    # 비균일 스케일 경고 (프리뷰와 실제 빛이 어긋남)
    if any(abs(v - 1.0) > 1e-4 for v in light_obj.scale):
        box = layout.box()
        box.label(text="비균일 스케일 감지 — 빛이 찌그러집니다", icon='ERROR')
        box.operator("fup.scrim_fix_scale", icon='CON_SIZELIMIT')

    # 실시간 프리뷰 (라이트 텍스처와 동일 픽셀)
    box = layout.box()
    box.label(text="프리뷰", icon='SHADING_RENDERED')
    icon_id = get_preview_icon()
    if icon_id:
        row = box.row()
        row.alignment = 'CENTER'
        row.template_icon(icon_value=icon_id, scale=11.0)
    else:
        box.label(text="프리뷰 생성 중...")

    layout.operator("fup.scrim_reset", icon='LOOP_BACK')

    # 기본
    col = layout.column(align=True)
    col.label(text="기본", icon='LIGHT_AREA')
    if "Color" in node.inputs:
        col.prop(node.inputs["Color"], "default_value", text="컬러")
    col.prop(light, "energy", text="밝기 (W)")
    col.prop(light, "shape", text="프레임 형태")
    if light.shape in {'RECTANGLE', 'ELLIPSE'}:
        col.prop(light, "size", text="프레임 가로")
        col.prop(light, "size_y", text="프레임 세로")
    else:
        col.prop(light, "size", text="프레임 크기")
    if hasattr(light, "spread"):
        col.prop(light, "spread", text="빛 퍼짐 (Spread)")

    layout.separator()

    # Scrim (LW와 동일 구성)
    col = layout.column(align=True)
    col.label(text="Scrim", icon='NODE_TEXTURE')
    for sock_name, label in (
        ("Feathering", "Feathering (사각↔원)"),
        ("Tilt H", "Horizontal Tilt (°)"),
        ("Tilt V", "Vertical Tilt (°)"),
        ("Imperfection", "Imperfection (불균일)"),
    ):
        if sock_name in node.inputs:
            col.prop(node.inputs[sock_name], "default_value",
                     text=label, slider=True)

    layout.separator()

    # 프레임 (고정)
    col = layout.column(align=True)
    col.label(text="스크림 프레임", icon='MESH_PLANE')
    col.prop(light_obj, "location", text="프레임 위치")
    col.prop(light_obj, "rotation_euler", text="프레임 회전")


# ---------- 패널 ----------

class LIGHT_PT_fup_scrim(bpy.types.Panel):
    bl_label = "FUP Scrim 라이트"
    bl_idname = "LIGHT_PT_fup_scrim"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "data"
    bl_order = 0

    @classmethod
    def poll(cls, context):
        ob = context.object
        return ob and ob.type == 'LIGHT'

    def draw(self, context):
        ob = context.object
        if get_scrim_node(ob.data):
            draw_scrim_ui(self.layout, context, ob)
        else:
            col = self.layout.column()
            col.label(text="이 라이트에는 Scrim이 없습니다", icon='INFO')
            if find_scrim_light_object(context):
                col.operator("fup.select_scrim_light", icon='LIGHT_AREA')


class VIEW3D_PT_fup_scrim(bpy.types.Panel):
    bl_label = "Scrim 라이트"
    bl_idname = "VIEW3D_PT_fup_scrim"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Scrim"

    def draw(self, context):
        light_obj = find_scrim_light_object(context)
        if light_obj is None:
            self.layout.label(text="씬에 Scrim 라이트가 없습니다", icon='INFO')
            return
        self.layout.label(text=light_obj.name, icon='LIGHT')
        draw_scrim_ui(self.layout, context, light_obj)


classes = (FUP_OT_scrim_convert, FUP_OT_scrim_fix_scale, FUP_OT_scrim_reset,
           FUP_OT_select_scrim_light, LIGHT_PT_fup_scrim, VIEW3D_PT_fup_scrim)


def register():
    global _pcoll, _prev_key
    for c in classes:
        bpy.utils.register_class(c)
    _pcoll = bpy.utils.previews.new()
    _prev_key = None
    if not bpy.app.background:
        bpy.app.timers.register(_preview_timer, first_interval=0.1,
                                persistent=True)


def unregister():
    global _pcoll
    if bpy.app.timers.is_registered(_preview_timer):
        bpy.app.timers.unregister(_preview_timer)
    if _pcoll is not None:
        bpy.utils.previews.remove(_pcoll)
        _pcoll = None
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
