# -*- coding: utf-8 -*-
"""
FUP DIFFUSER — 스코틀랜드 석양 씬 노드 레시피
THE GOLDEN RETRIEVER TVC(2026)에서 실제로 쓴 Blender 노드 셋업을 재사용 가능한 함수로 정리한 것.

사용법 (Blender 텍스트 에디터 또는 헤드리스):
    blender your.blend -P scotland_nodes.py

각 함수를 개별 호출해도 됩니다:
    build_deep_orange_sky("kiara_8_sunset_4k.exr", rot_deg=215, sat=1.75, val=0.45)
    build_fog_stack()          # 거리별 4겹 안개
    build_film_grain(0.35)     # 필름 그레인 컴포지터

라이선스: 자유 사용 (FUP / from us project). 참고용으로 제공합니다.
"""
import bpy
import math


# ──────────────────────────────────────────────────────────────
# 1) 하늘 — HDRI를 딥오렌지로 그레이딩하는 World
#    Environment Texture와 Background 사이에 Hue/Saturation을 끼우는 게 핵심.
#    이 한 노드가 배경 그림 + 씬 환경광 전체를 물들인다.
# ──────────────────────────────────────────────────────────────
def build_deep_orange_sky(hdri_path, rot_deg=215, sat=1.75, val=0.45):
    w = bpy.data.worlds.new("ScotlandSky")
    w.use_nodes = True
    nt = w.node_tree
    nt.nodes.clear()

    out = nt.nodes.new("ShaderNodeOutputWorld")
    bg = nt.nodes.new("ShaderNodeBackground")
    env = nt.nodes.new("ShaderNodeTexEnvironment")
    env.image = bpy.data.images.load(hdri_path)
    tc = nt.nodes.new("ShaderNodeTexCoord")
    mp = nt.nodes.new("ShaderNodeMapping")
    mp.inputs["Rotation"].default_value = (0, 0, math.radians(rot_deg))  # 태양 방향
    hs = nt.nodes.new("ShaderNodeHueSaturation")
    hs.inputs["Saturation"].default_value = sat   # 채도 ↑
    hs.inputs["Value"].default_value = val         # 명도 ↓  → 딥오렌지

    L = nt.links.new
    L(tc.outputs["Generated"], mp.inputs["Vector"])
    L(mp.outputs["Vector"], env.inputs["Vector"])
    L(env.outputs["Color"], hs.inputs["Color"])
    L(hs.outputs["Color"], bg.inputs["Color"])
    L(bg.outputs["Background"], out.inputs["Surface"])
    bpy.context.scene.world = w
    return w


# ──────────────────────────────────────────────────────────────
# 2) 안개 — 거리별 4겹
#    안개 하나만 깔면 우윳빛으로 뭉개진다. 밀도·위치·색이 다른 네 겹을
#    근경→원경으로 쌓고, 안개 구간을 제품 뒤(y 0~13m)로만 밀어
#    제품은 또렷하게 · 배경만 미스티하게 만든다.
# ──────────────────────────────────────────────────────────────
def _add_fog_cube(name, loc, scale):
    bpy.ops.mesh.primitive_cube_add(location=loc)
    cube = bpy.context.active_object
    cube.name = name
    cube.scale = scale
    cube.display_type = 'WIRE'
    cube.hide_render = False
    return cube


def _fog_layer(name, loc, scale, density, ncolor, aniso):
    cube = _add_fog_cube(name, loc, scale)
    mat = bpy.data.materials.new(name + "_M")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    vol = nt.nodes.new("ShaderNodeVolumePrincipled")
    vol.inputs["Density"].default_value = density
    vol.inputs["Color"].default_value = ncolor
    vol.inputs["Anisotropy"].default_value = aniso
    nt.links.new(vol.outputs["Volume"], out.inputs["Volume"])
    cube.data.materials.append(mat)
    return cube


def build_fog_stack():
    # (이름, 위치, 스케일, 밀도, 색 RGBA, 이방성)
    _fog_layer("FogNear",     (0, 1.75, 0.18), (36, 0.7, 0.42), 0.45,
               (0.92, 0.82, 0.70, 1), 0.55)   # 근경 자락
    _fog_layer("MistBand",    (0, 3.2,  0.5),  (12, 1.8, 1.1),  0.30,
               (0.95, 0.88, 0.78, 1), 0.55)   # 중경 발광 안개벽 (역광 받아 타오름)
    _fog_layer("FogFar",      (0, 18,   1.8),  (60, 8,   2.6),  0.10,
               (0.78, 0.76, 0.78, 1), 0.30)   # 원경 계곡
    _fog_layer("HighlandFog", (0, 5,    2.5),  (30, 30,  7.0),  0.012,
               (0.75, 0.78, 0.80, 1), 0.15)   # 전역 대기 헤이즈


# ──────────────────────────────────────────────────────────────
# 3) 필름 그레인 — NOISE(프레임마다 자동 변화) → 블러 → 곱셈 합성
#    ADD로 하면 AgX 톤매핑이 눌러버린다. (1+grain)을 곱하면
#    밝은 픽셀일수록 입자가 도드라져 필름 질감이 자연스럽다.
# ──────────────────────────────────────────────────────────────
def build_film_grain(amount=0.35):
    scene = bpy.context.scene
    scene.use_nodes = True
    nt = scene.node_tree
    nt.nodes.clear()
    L = nt.links.new

    rl = nt.nodes.new('CompositorNodeRLayers')
    comp = nt.nodes.new('CompositorNodeComposite')

    tex = bpy.data.textures.new('FilmGrain', 'NOISE')     # 프레임마다 자동 변화
    tn = nt.nodes.new('CompositorNodeTexture')
    tn.texture = tex
    bl = nt.nodes.new('CompositorNodeBlur')
    bl.filter_type = 'FAST_GAUSS'
    bl.size_x = 1
    bl.size_y = 1                                          # 1px 블러
    L(tn.outputs['Value'], bl.inputs['Image'])

    sub = nt.nodes.new('CompositorNodeMath')
    sub.operation = 'SUBTRACT'
    sub.inputs[1].default_value = 0.5                      # -0.5 ~ +0.5
    L(bl.outputs['Image'], sub.inputs[0])

    amt = nt.nodes.new('CompositorNodeValue')
    amt.name = 'GrainAmount'
    amt.outputs[0].default_value = amount                 # 강도
    mul = nt.nodes.new('CompositorNodeMath')
    mul.operation = 'MULTIPLY'
    L(sub.outputs['Value'], mul.inputs[0])
    L(amt.outputs[0], mul.inputs[1])

    add1 = nt.nodes.new('CompositorNodeMath')
    add1.operation = 'ADD'
    add1.inputs[1].default_value = 1.0                    # (1 + grain)
    L(mul.outputs['Value'], add1.inputs[0])

    mix = nt.nodes.new('CompositorNodeMixRGB')
    mix.blend_type = 'MULTIPLY'
    mix.inputs['Fac'].default_value = 1.0                 # 이미지 × (1+grain)
    L(rl.outputs['Image'], mix.inputs[1])
    L(add1.outputs['Value'], mix.inputs[2])
    L(mix.outputs['Image'], comp.inputs['Image'])


if __name__ == "__main__":
    # 예시: HDRI 경로만 바꿔서 실행하면 3가지가 모두 세팅됩니다.
    # build_deep_orange_sky("/path/to/kiara_8_sunset_4k.exr")
    # build_fog_stack()
    # build_film_grain(0.35)
    print("scotland_nodes.py — 함수를 개별 호출해 쓰세요. (하단 주석 참고)")
